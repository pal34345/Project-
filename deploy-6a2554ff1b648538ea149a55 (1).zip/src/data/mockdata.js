// ═══════════════════════════════════════════════
// ADAPTIVE WORKPLACE OS — MOCK DATA
// ═══════════════════════════════════════════════

const MOCK = {
  user: { name: "Pallab B.C.", department: "Product Engineering", feasibility: 82 },

  tasks: [
    { id:1, name:"Q2 Client Report — Escalation Review",  priority:"high",  deadline:"Today 5PM",  autoSubmit:true,  done:false },
    { id:2, name:"Azure AI Foundry Integration Setup",    priority:"high",  deadline:"Today 7PM",  autoSubmit:false, done:false },
    { id:3, name:"Audit Checklist — Compliance Review",   priority:"mid",   deadline:"Jun 8",      autoSubmit:true,  done:false },
    { id:4, name:"Weekly Standup Notes",                  priority:"mid",   deadline:"Jun 8",      autoSubmit:true,  done:true  },
    { id:5, name:"GenAI Audit Session — Image Dataset",   priority:"mid",   deadline:"Jun 9",      autoSubmit:false, done:false },
    { id:6, name:"Innovation Bot — Test Prompt Flow",     priority:"low",   deadline:"Jun 10",     autoSubmit:false, done:false },
    { id:7, name:"Team Dashboard Preload Config",         priority:"low",   deadline:"Jun 11",     autoSubmit:true,  done:false },
  ],

  projects: [
    { id:1, name:"Adaptive Workplace OS — Phase 1", feasibility:82, progress:68, deadline:"Jun 30", autonomous:true  },
    { id:2, name:"Knowledge Repository Migration",   feasibility:71, progress:40, deadline:"Jul 15", autonomous:true  },
    { id:3, name:"GenAI Audit Pipeline",             feasibility:55, progress:22, deadline:"Aug 1",  autonomous:false },
  ],

  meetings: [
    {
      id:1, title:"Client Escalation Review", time:"Today, 10:00 AM", duration:"45 min",
      attendees:["Pallab", "Ritu S.", "Ankit M."],
      summary:"Discussed Q2 delivery delays. Client requires updated roadmap by Friday. Action: Pallab to draft revised timeline and share by EOD Thursday.",
      actionItems:["Draft revised timeline", "Schedule follow-up for Jun 10", "Update Jira board"],
      transcript:[
        { speaker:"Ritu S.",  text:"The client flagged the delivery slipping by two weeks." },
        { speaker:"Pallab",   text:"I can have the revised roadmap ready by Thursday EOD." },
        { speaker:"Ankit M.", text:"We should loop in the QA team for sign-off before sharing." },
      ]
    },
    {
      id:2, title:"Azure AI Foundry Planning", time:"Yesterday, 3:00 PM", duration:"30 min",
      attendees:["Pallab", "Deepa K.", "Suresh P."],
      summary:"Reviewed Azure AI Foundry integration options. Agreed to use gpt-4o model endpoint. Cost estimate approved at $200/month for prototype phase.",
      actionItems:["Provision Azure OpenAI resource", "Set up staging environment", "Document API schema"],
      transcript:[
        { speaker:"Deepa K.", text:"The gpt-4o endpoint fits our latency requirements." },
        { speaker:"Pallab",   text:"Let's provision it today and test the document intelligence pipeline." },
        { speaker:"Suresh P.",text:"I'll set up the staging environment by end of week." },
      ]
    },
    {
      id:3, title:"GenAI Audit Strategy", time:"Jun 5, 2:00 PM", duration:"60 min",
      attendees:["Pallab", "Compliance Team"],
      summary:"Agreed on prompt-driven audit approach for images and documents. Testing session will cover data integrity, format compliance, and anomaly detection.",
      actionItems:["Define audit prompt templates", "Collect sample dataset", "Run pilot test session"],
      transcript:[
        { speaker:"Pallab",    text:"We'll use Azure AI Document Intelligence for structured data extraction." },
        { speaker:"Compliance",text:"The image audit needs to flag resolution and metadata inconsistencies." },
      ]
    },
  ],

  audit: {
    overallScore: 91,
    lastRun: "Jun 6, 2026 — 4:32 PM",
    checks: [
      { label:"Data Format Compliance",    score:96, status:"pass" },
      { label:"Image Metadata Validation", score:88, status:"pass" },
      { label:"Document Structure Check",  score:94, status:"pass" },
      { label:"Anomaly Detection",         score:82, status:"warn" },
      { label:"Access Control Audit",      score:97, status:"pass" },
      { label:"Policy Adherence Review",   score:89, status:"pass" },
    ]
  },

  ideas: [
    { id:1, title:"Seasonal OS Skin — Automated Theme Switching",    submittedBy:"Pallab", date:"Jun 5", status:"escalated", brief:"AI detects seasonal context and applies workspace themes. Improves employee engagement by 18% (internal benchmark)." },
    { id:2, title:"Feasibility-Weighted Sprint Planner",             submittedBy:"Pallab", date:"Jun 4", status:"stored",    brief:"Auto-assign project tasks based on individual feasibility scores rather than manual sprint planning." },
    { id:3, title:"Zero-Format Email — Prompt to Send",             submittedBy:"Pallab", date:"Jun 3", status:"escalated", brief:"Employees type intent in plain language; AI structures, formats and routes the email automatically." },
    { id:4, title:"Cross-Department Knowledge Graph",               submittedBy:"Pallab", date:"Jun 2", status:"stored",    brief:"Build a graph of inter-departmental knowledge dependencies to surface hidden expertise and reduce duplication." },
    { id:5, title:"Meeting Fatigue Detector — Workload Alert",      submittedBy:"Pallab", date:"Jun 1", status:"pending",   brief:"Monitor meeting hours vs productive task time ratio and flag overloaded employees to their manager." },
  ],

  management: {
    productivity:   { score: 84, trend: "+6% vs last month" },
    auditPassRate:  { score: 94, trend: "Stable" },
    ideaBriefs:     { count: 4,  latest: "Jun 5" },
    autonomyScore:  { score: 71, trend: "↑ from 58%" },
    taskCompletion: { score: 78, trend: "+11% this week" },
    meetingEfficiency: { score: 88, trend: "↑ action items resolved 3x faster" },
  },

  botResponses: {
    "summarise":         "Here's a summary of today's key meetings:\n\n• **Client Escalation Review** — Delivery delay flagged. Revised roadmap due Thursday.\n• **Azure AI Foundry Planning** — gpt-4o endpoint approved. Staging by EOD Friday.\n\nTotal: 2 action items assigned to you.",
    "audit":             "Latest GenAI Audit Session (Jun 6):\n\n✅ Overall Score: **91/100**\n⚠️ Anomaly Detection flagged 3 edge cases in the image dataset — review recommended.\n✅ All other checks passed.",
    "email":             "Here's a draft email to your Project Manager:\n\n---\nSubject: Revised Roadmap — Q2 Delivery Update\n\nHi [PM Name],\n\nFollowing today's escalation review, I've updated the delivery timeline. The revised roadmap is attached. Key change: Phase 2 delivery moved to June 28.\n\nPlease confirm by Thursday EOD.\n\nBest,\nPallab\n---",
    "idea":              "Idea logged ✅\n\nYour idea has been stored to the Innovation Repository. A brief and summary will be auto-generated and escalated to your department head within 24 hours.",
    "tasks":             "Today's auto-submitted tasks:\n\n✅ Q2 Client Report — submitted 9:01 AM\n✅ Audit Checklist — queued for EOD auto-submit\n✅ Weekly Standup Notes — submitted\n\n2 tasks require your manual action today.",
    "default":           "I've logged your request. Based on your current workload (Feasibility: 82%), I recommend prioritising the Q2 Client Report first. Would you like me to draft a response, schedule time, or escalate this to your manager?"
  }
};
