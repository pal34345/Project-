// ═══════════════════════════════════════════════
// INNOVATION BOT VIEW
// ═══════════════════════════════════════════════

function renderIdeas() {
  return `
    <div style="display:flex;flex-direction:column;gap:20px">

      <div class="section-header">
        <div>
          <div class="section-title">Innovation Bot</div>
          <div class="section-sub">Ideas captured → stored to repository → brief auto-generated → escalated to management</div>
        </div>
        <div style="display:flex;gap:8px">
          <span style="background:rgba(255,185,0,0.12);border:1px solid rgba(255,185,0,0.3);color:#FFB900;font-size:11px;font-weight:600;padding:5px 12px;border-radius:6px">${MOCK.ideas.length} ideas logged</span>
          <span style="background:rgba(0,178,148,0.12);border:1px solid rgba(0,178,148,0.3);color:#00B294;font-size:11px;font-weight:600;padding:5px 12px;border-radius:6px">${MOCK.ideas.filter(i=>i.status==='escalated').length} escalated</span>
        </div>
      </div>

      <!-- Pipeline Banner -->
      <div style="background:rgba(255,185,0,0.06);border:1px solid rgba(255,185,0,0.2);border-radius:10px;padding:16px 20px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
          <div style="text-align:center;flex:1">
            <div style="font-size:20px">💬</div>
            <div style="font-size:11px;color:#E8EFF7;margin-top:4px;font-weight:600">Capture</div>
            <div style="font-size:10px;color:#8496AB">Bot prompt</div>
          </div>
          <div style="color:#FFB900;font-size:18px">→</div>
          <div style="text-align:center;flex:1">
            <div style="font-size:20px">📦</div>
            <div style="font-size:11px;color:#E8EFF7;margin-top:4px;font-weight:600">Store</div>
            <div style="font-size:10px;color:#8496AB">Repository</div>
          </div>
          <div style="color:#FFB900;font-size:18px">→</div>
          <div style="text-align:center;flex:1">
            <div style="font-size:20px">📝</div>
            <div style="font-size:11px;color:#E8EFF7;margin-top:4px;font-weight:600">Auto-Brief</div>
            <div style="font-size:10px;color:#8496AB">AI generates</div>
          </div>
          <div style="color:#FFB900;font-size:18px">→</div>
          <div style="text-align:center;flex:1">
            <div style="font-size:20px">📊</div>
            <div style="font-size:11px;color:#E8EFF7;margin-top:4px;font-weight:600">Escalate</div>
            <div style="font-size:10px;color:#8496AB">Management</div>
          </div>
        </div>
      </div>

      <div class="grid-2" style="align-items:start">

        <!-- Submit Idea -->
        <div class="card">
          <div class="card-title">Submit an Idea</div>
          <div style="display:flex;flex-direction:column;gap:12px">
            <div>
              <label style="font-size:11px;color:#8496AB;display:block;margin-bottom:6px">Idea Title</label>
              <input id="ideaTitle" type="text" placeholder="e.g. AI-powered onboarding assistant…" style="width:100%;background:var(--navy3);border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:9px 12px;color:#E8EFF7;font-family:'DM Sans',sans-serif;font-size:13px;outline:none" />
            </div>
            <div>
              <label style="font-size:11px;color:#8496AB;display:block;margin-bottom:6px">Description</label>
              <textarea id="ideaDesc" placeholder="Describe the idea, problem it solves, and expected impact…" style="width:100%;height:90px;background:var(--navy3);border:1px solid rgba(255,255,255,0.08);border-radius:6px;padding:9px 12px;color:#E8EFF7;font-family:'DM Sans',sans-serif;font-size:12px;line-height:1.6;outline:none;resize:vertical"></textarea>
            </div>
            <button class="btn btn-orange" style="width:100%" onclick="IdeaBot.submitIdea()">💡 Log Idea to Repository</button>
            <div id="ideaSubmitStatus" style="display:none;background:rgba(0,178,148,0.08);border:1px solid rgba(0,178,148,0.2);border-radius:6px;padding:12px;font-size:12px;color:#00B294;line-height:1.6">
              ✅ Idea stored to repository.<br>
              📝 AI brief auto-generated.<br>
              ↑ Escalated to department head.
            </div>
          </div>
        </div>

        <!-- Idea Repository -->
        <div class="card">
          <div class="card-title">Innovation Repository</div>
          <div style="display:flex;flex-direction:column;gap:10px" id="ideaList">
            ${MOCK.ideas.map(idea => `
              <div class="idea-card">
                <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
                  <div class="idea-title">${idea.title}</div>
                  <span class="idea-status status-${idea.status}">
                    ${idea.status === 'escalated' ? '↑ Escalated' : idea.status === 'stored' ? '📦 Stored' : '⏳ Pending'}
                  </span>
                </div>
                <div style="font-size:12px;color:#E8EFF7;line-height:1.6">${idea.brief}</div>
                <div style="display:flex;align-items:center;justify-content:space-between">
                  <div class="idea-meta">${idea.submittedBy} · ${idea.date}</div>
                  ${idea.status !== 'escalated' ? `<button class="btn btn-ghost" style="font-size:10px;padding:4px 10px" onclick="IdeaBot.escalate(${idea.id})">↑ Escalate</button>` : '<span style="font-size:10px;color:#00B294">✅ Management notified</span>'}
                </div>
              </div>
            `).join('')}
          </div>
        </div>

      </div>
    </div>
  `;
}

const IdeaBot = {
  submitIdea() {
    const title = document.getElementById('ideaTitle');
    const desc  = document.getElementById('ideaDesc');
    const status = document.getElementById('ideaSubmitStatus');
    if (!title || !title.value.trim()) {
      App.showToast('⚠ Please enter an idea title');
      return;
    }
    const newIdea = {
      id: MOCK.ideas.length + 1,
      title: title.value.trim(),
      submittedBy: 'Pallab',
      date: 'Today',
      status: 'stored',
      brief: desc && desc.value.trim() ? desc.value.trim() : 'Idea submitted via Innovation Bot. AI brief pending generation.'
    };
    MOCK.ideas.unshift(newIdea);
    title.value = '';
    if (desc) desc.value = '';
    if (status) status.style.display = 'block';
    App.showToast('💡 Idea stored → AI brief generated → Escalated to management');
    setTimeout(() => { App.navigate('ideas'); }, 1500);
  },
  escalate(id) {
    const idea = MOCK.ideas.find(i => i.id === id);
    if (idea) {
      idea.status = 'escalated';
      App.navigate('ideas');
      App.showToast('↑ Idea escalated — brief sent to department head');
    }
  }
};
