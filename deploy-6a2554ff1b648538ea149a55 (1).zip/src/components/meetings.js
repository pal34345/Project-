// ═══════════════════════════════════════════════
// MEETINGS VIEW
// ═══════════════════════════════════════════════

let selectedMeeting = 0;

function renderMeetings() {
  const m = MOCK.meetings[selectedMeeting];
  return `
    <div style="display:flex;flex-direction:column;gap:20px">

      <div class="section-header">
        <div>
          <div class="section-title">Meeting Intelligence Hub</div>
          <div class="section-sub">All meetings transcribed, summarised and stored automatically</div>
        </div>
        <button class="btn btn-primary">+ New Meeting</button>
      </div>

      <div class="grid-2" style="align-items:start">

        <!-- Meeting List -->
        <div style="display:flex;flex-direction:column;gap:10px">
          ${MOCK.meetings.map((mt, i) => `
            <div onclick="Meetings.select(${i})" style="background:${i===selectedMeeting?'rgba(0,120,212,0.12)':'var(--navy3)'};border:1px solid ${i===selectedMeeting?'rgba(0,120,212,0.4)':'rgba(255,255,255,0.05)'};border-radius:10px;padding:16px;cursor:pointer;transition:all 0.2s">
              <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
                <div style="font-size:14px;font-weight:600;color:#fff">${mt.title}</div>
                <span style="font-size:10px;color:#8496AB;white-space:nowrap">${mt.duration}</span>
              </div>
              <div style="font-size:11px;color:#8496AB;margin-top:4px">${mt.time}</div>
              <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
                ${mt.attendees.map(a => `<span style="background:rgba(0,188,242,0.1);color:#00BCF2;font-size:10px;padding:2px 7px;border-radius:3px">${a}</span>`).join('')}
              </div>
            </div>
          `).join('')}
        </div>

        <!-- Meeting Detail -->
        <div style="display:flex;flex-direction:column;gap:14px" id="meetingDetail">
          <!-- AI Summary -->
          <div class="card">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
              <span style="font-size:18px">◉</span>
              <div class="card-title" style="margin-bottom:0">AI Summary</div>
            </div>
            <div style="font-family:'Syne',sans-serif;font-size:15px;font-weight:700;color:#fff;margin-bottom:8px">${m.title}</div>
            <div style="font-size:11px;color:#8496AB;margin-bottom:12px">${m.time} · ${m.duration} · ${m.attendees.join(', ')}</div>
            <div style="font-size:13px;color:#E8EFF7;line-height:1.7;margin-bottom:14px">${m.summary}</div>
            <div class="card-title" style="margin-bottom:8px">Action Items</div>
            <div style="display:flex;flex-direction:column;gap:7px">
              ${m.actionItems.map(a => `
                <div style="display:flex;align-items:center;gap:10px;background:var(--navy3);padding:9px 12px;border-radius:6px">
                  <span style="color:#00BCF2;font-size:14px">→</span>
                  <span style="font-size:12px;color:#E8EFF7">${a}</span>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Transcript -->
          <div class="card">
            <div class="card-title">Transcript Excerpt</div>
            <div class="transcript-block">
              ${m.transcript.map(t => `<p><b>${t.speaker}:</b> ${t.text}</p>`).join('<br>')}
            </div>
            <div style="display:flex;gap:8px;margin-top:12px">
              <button class="btn btn-ghost" style="font-size:12px" onclick="App.showToast('📋 Summary copied to clipboard')">Copy Summary</button>
              <button class="btn btn-ghost" style="font-size:12px" onclick="App.showToast('📧 Email drafted from meeting notes')">Email Draft</button>
              <button class="btn btn-ghost" style="font-size:12px" onclick="App.showToast('📦 Stored to Knowledge Repository')">→ Repository</button>
            </div>
          </div>

        </div>

      </div>
    </div>
  `;
}

const Meetings = {
  select(i) {
    selectedMeeting = i;
    App.navigate('meetings');
  }
};
