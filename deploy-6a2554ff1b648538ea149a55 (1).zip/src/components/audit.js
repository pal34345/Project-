// ═══════════════════════════════════════════════
// GENAI AUDIT VIEW
// ═══════════════════════════════════════════════

let auditRunning = false;
let auditComplete = false;

function renderAudit() {
  const a = MOCK.audit;
  const pct = (a.overallScore / 100 * 360);

  return `
    <div style="display:flex;flex-direction:column;gap:20px">

      <div class="section-header">
        <div>
          <div class="section-title">GenAI Audit Engine</div>
          <div class="section-sub">Audit images and data via GenAI testing session · Prompt-driven compliance scoring</div>
        </div>
        <button class="btn btn-primary" id="runAuditBtn" onclick="AuditEngine.startSession()">▶ Start Audit Session</button>
      </div>

      <div class="grid-2" style="align-items:start">

        <!-- Upload + Session -->
        <div style="display:flex;flex-direction:column;gap:14px">

          <!-- Upload Zone -->
          <div class="card">
            <div class="card-title">Upload for Audit</div>
            <div class="upload-zone" onclick="AuditEngine.fakeUpload()">
              <div class="upload-icon">◇</div>
              <div class="upload-label">Drop images or data files here</div>
              <div class="upload-hint">Supported: PNG, JPEG, PDF, CSV, DOCX</div>
              <button class="btn btn-ghost" style="font-size:12px;margin-top:6px">Browse Files</button>
            </div>
            <div id="uploadStatus" style="display:none;margin-top:12px;background:rgba(0,178,148,0.08);border:1px solid rgba(0,178,148,0.2);border-radius:6px;padding:10px 14px;font-size:12px;color:#00B294">
              ✅ 3 files uploaded — ready for audit session
            </div>
          </div>

          <!-- Audit Prompt -->
          <div class="card">
            <div class="card-title">Audit Prompt</div>
            <textarea id="auditPrompt" style="width:100%;height:100px;background:var(--navy3);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:12px;color:#E8EFF7;font-family:'DM Sans',sans-serif;font-size:12px;line-height:1.6;outline:none;resize:vertical" placeholder="Describe what to audit, e.g.: Check all images for metadata compliance, flag resolution below 72dpi, and verify document structure against Q2 policy standards…">Check uploaded images for metadata completeness, resolution compliance (min 150dpi), and structural consistency. Flag any anomalies and generate a compliance score.</textarea>
            <div style="display:flex;gap:8px;margin-top:10px">
              <button class="btn btn-primary" style="font-size:12px" onclick="AuditEngine.startSession()">▶ Run Session</button>
              <button class="btn btn-ghost" style="font-size:12px" onclick="AuditEngine.clearPrompt()">Clear</button>
            </div>
          </div>

          <!-- Last Run Info -->
          <div class="card" style="background:rgba(0,120,212,0.06);border-color:rgba(0,120,212,0.2)">
            <div style="font-size:12px;color:#8496AB;margin-bottom:4px">Last Session</div>
            <div style="font-size:13px;color:#E8EFF7">${a.lastRun}</div>
            <div style="font-size:12px;color:#00B294;margin-top:4px">Overall Score: ${a.overallScore}/100 · All critical checks passed</div>
          </div>

        </div>

        <!-- Results Panel -->
        <div style="display:flex;flex-direction:column;gap:14px">

          <!-- Score Ring -->
          <div class="card">
            <div class="card-title">Compliance Score</div>
            <div style="display:flex;align-items:center;gap:24px;margin-bottom:16px">
              <div class="audit-score-ring" style="--pct:${pct}deg">
                <div class="audit-score-val">${a.overallScore}</div>
              </div>
              <div>
                <div style="font-family:'Syne',sans-serif;font-size:28px;font-weight:800;color:#fff">${a.overallScore}<span style="font-size:16px;color:#8496AB">/100</span></div>
                <div style="font-size:12px;color:#00B294;margin-top:4px">✅ Audit Passed</div>
                <div style="font-size:11px;color:#8496AB;margin-top:2px">1 warning flagged</div>
              </div>
            </div>

            <!-- Check Results -->
            <div>
              ${a.checks.map(c => `
                <div class="audit-row">
                  <div style="display:flex;align-items:center;gap:8px;flex:1">
                    <span style="font-size:14px">${c.status==='pass'?'✅':'⚠️'}</span>
                    <span style="color:#E8EFF7">${c.label}</span>
                  </div>
                  <div style="display:flex;align-items:center;gap:10px">
                    <div style="width:80px;height:4px;background:var(--navy3);border-radius:2px;overflow:hidden">
                      <div style="height:100%;width:${c.score}%;background:${c.status==='pass'?'var(--green)':'var(--orange)'};border-radius:2px"></div>
                    </div>
                    <span style="font-size:12px;color:${c.status==='pass'?'#00B294':'#F7630C'};font-weight:600;min-width:32px">${c.score}</span>
                  </div>
                </div>
              `).join('')}
            </div>

            <div style="display:flex;gap:8px;margin-top:14px">
              <button class="btn btn-ghost" style="font-size:12px" onclick="App.showToast('📄 Audit report exported')">Export Report</button>
              <button class="btn btn-ghost" style="font-size:12px" onclick="App.showToast('📦 Stored to repository')">→ Repository</button>
              <button class="btn btn-ghost" style="font-size:12px" onclick="App.showToast('📧 Report emailed to compliance team')">Email Report</button>
            </div>
          </div>

        </div>
      </div>

      <!-- Running Overlay -->
      <div id="auditRunOverlay" style="display:none;position:fixed;inset:0;background:rgba(15,27,45,0.85);z-index:800;align-items:center;justify-content:center;flex-direction:column;gap:16px">
        <div style="font-family:'Syne',sans-serif;font-size:24px;font-weight:700;color:#fff">Running GenAI Audit Session</div>
        <div class="loading-dots" style="display:flex;align-items:center;gap:4px"><span></span><span></span><span></span></div>
        <div id="auditStep" style="font-size:13px;color:#8496AB;margin-top:6px">Initialising Azure AI Document Intelligence…</div>
      </div>

    </div>
  `;
}

const AuditEngine = {
  fakeUpload() {
    const s = document.getElementById('uploadStatus');
    if (s) { s.style.display = 'block'; }
    App.showToast('📎 3 files uploaded successfully');
  },
  clearPrompt() {
    const p = document.getElementById('auditPrompt');
    if (p) p.value = '';
  },
  startSession() {
    const overlay = document.getElementById('auditRunOverlay');
    const stepEl  = document.getElementById('auditStep');
    if (!overlay) return;
    overlay.style.display = 'flex';
    const steps = [
      'Initialising Azure AI Document Intelligence…',
      'Extracting metadata from uploaded files…',
      'Running anomaly detection pipeline…',
      'Scoring compliance against policy standards…',
      'Generating audit report…',
      'Session complete ✅'
    ];
    let i = 0;
    const iv = setInterval(() => {
      if (stepEl) stepEl.textContent = steps[i];
      i++;
      if (i >= steps.length) {
        clearInterval(iv);
        setTimeout(() => {
          overlay.style.display = 'none';
          App.showToast('✅ Audit session complete — Score: 91/100');
        }, 800);
      }
    }, 900);
  }
};
