// ═══════════════════════════════════════════════
// DASHBOARD VIEW
// ═══════════════════════════════════════════════

function renderDashboard() {
  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const dateStr = now.toLocaleDateString("en-GB", { weekday:"long", day:"numeric", month:"long", year:"numeric" });

  const todayTasks    = MOCK.tasks.filter(t => !t.done);
  const autoSubmitted = MOCK.tasks.filter(t => t.autoSubmit && t.done).length;
  const highPriority  = MOCK.tasks.filter(t => t.priority === "high" && !t.done).length;

  return `
    <div style="display:flex;flex-direction:column;gap:20px">

      <!-- Welcome Banner -->
      <div style="background:linear-gradient(135deg,#162236 0%,#1A2D45 60%,#0F3460 100%);border-radius:12px;padding:24px 28px;border:1px solid rgba(0,120,212,0.2);display:flex;align-items:center;justify-content:space-between;">
        <div>
          <div style="font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:#fff;margin-bottom:4px">${greeting}, Pallab</div>
          <div style="font-size:12px;color:#8496AB">${dateStr}</div>
          <div style="display:flex;gap:16px;margin-top:14px">
            <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:#E8EFF7">
              <span style="color:#D13438;font-size:14px">●</span>
              <strong>${highPriority}</strong> high priority tasks
            </div>
            <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:#E8EFF7">
              <span style="color:#00B294;font-size:14px">●</span>
              <strong>${autoSubmitted}</strong> auto-submitted today
            </div>
            <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:#E8EFF7">
              <span style="color:#00BCF2;font-size:14px">●</span>
              Feasibility score: <strong>${MOCK.user.feasibility}%</strong>
            </div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:16px">
          <div class="feasibility-ring" style="--pct:${MOCK.user.feasibility * 3.6}deg">
            <div class="feasibility-val">${MOCK.user.feasibility}%</div>
          </div>
          <div>
            <div style="font-size:11px;color:#8496AB;text-transform:uppercase;letter-spacing:0.06em">Feasibility</div>
            <div style="font-size:12px;color:#E8EFF7;margin-top:4px">Project Autonomy</div>
            <div style="font-size:11px;color:#00B294;margin-top:2px">↑ Autonomous scheduling active</div>
          </div>
        </div>
      </div>

      <!-- Stat Row -->
      <div class="grid-4">
        <div class="stat-tile">
          <div class="stat-label">Tasks Today</div>
          <div class="stat-value">${todayTasks.length}</div>
          <div class="stat-sub">${autoSubmitted} auto-submitted</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">Audit Score</div>
          <div class="stat-value">${MOCK.audit.overallScore}</div>
          <div class="stat-sub">Last run Jun 6</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">Ideas Logged</div>
          <div class="stat-value">${MOCK.ideas.length}</div>
          <div class="stat-sub warn">${MOCK.ideas.filter(i=>i.status==='escalated').length} escalated to mgmt</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">Meetings</div>
          <div class="stat-value">${MOCK.meetings.length}</div>
          <div class="stat-sub">All transcribed</div>
        </div>
      </div>

      <!-- Main 2-col -->
      <div class="grid-2">

        <!-- Today's Priorities -->
        <div class="card">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
            <div class="card-title" style="margin-bottom:0">Today's Priorities</div>
            <span style="font-size:11px;color:#00BCF2;cursor:pointer" onclick="App.navigate('tasks')">View all →</span>
          </div>
          <div class="task-list">
            ${MOCK.tasks.slice(0,4).map(t => `
              <div class="task-item ${t.done?'done':''}" onclick="App.navigate('tasks')">
                <div class="task-check ${t.done?'checked':''}">${t.done?'✓':''}</div>
                <div class="task-name">${t.name}</div>
                <div class="task-meta">
                  <span class="tag tag-${t.priority==='high'?'high':t.priority==='mid'?'mid':'low'}">${t.priority}</span>
                  ${t.autoSubmit ? '<span class="tag tag-auto">Auto</span>' : ''}
                  <span class="task-deadline">${t.deadline}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Active Projects -->
        <div class="card">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
            <div class="card-title" style="margin-bottom:0">Active Projects</div>
            <span style="font-size:11px;color:#00BCF2;cursor:pointer">Autonomous mode ON</span>
          </div>
          <div style="display:flex;flex-direction:column;gap:14px">
            ${MOCK.projects.map(p => `
              <div style="display:flex;flex-direction:column;gap:6px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                  <div style="font-size:13px;color:#E8EFF7;font-weight:500">${p.name}</div>
                  <div style="font-size:11px;color:#8496AB">${p.deadline}</div>
                </div>
                <div style="display:flex;align-items:center;gap:10px">
                  <div class="progress-bar" style="flex:1">
                    <div class="progress-fill" style="width:${p.progress}%;background:${p.autonomous?'var(--cyan)':'var(--orange)'}"></div>
                  </div>
                  <span style="font-size:11px;color:#8496AB;min-width:30px">${p.progress}%</span>
                  <span style="font-size:10px;color:${p.autonomous?'#00B294':'#F7630C'};font-weight:600">${p.autonomous?'AUTO':'MANUAL'}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

      </div>

      <!-- Recent Meetings & Ideas Row -->
      <div class="grid-2">

        <!-- Recent Meeting Summary -->
        <div class="card">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
            <div class="card-title" style="margin-bottom:0">Latest Meeting Summary</div>
            <span style="font-size:11px;color:#00BCF2;cursor:pointer" onclick="App.navigate('meetings')">All meetings →</span>
          </div>
          <div style="font-weight:600;font-size:14px;color:#fff;margin-bottom:4px">${MOCK.meetings[0].title}</div>
          <div style="font-size:11px;color:#8496AB;margin-bottom:10px">${MOCK.meetings[0].time} · ${MOCK.meetings[0].duration}</div>
          <div style="font-size:12px;color:#E8EFF7;line-height:1.6;margin-bottom:12px">${MOCK.meetings[0].summary}</div>
          <div style="display:flex;flex-direction:column;gap:5px">
            ${MOCK.meetings[0].actionItems.map(a => `
              <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#8496AB">
                <span style="color:#00BCF2">→</span> ${a}
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Recent Ideas -->
        <div class="card">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
            <div class="card-title" style="margin-bottom:0">Innovation Pipeline</div>
            <span style="font-size:11px;color:#00BCF2;cursor:pointer" onclick="App.navigate('ideas')">View all →</span>
          </div>
          <div style="display:flex;flex-direction:column;gap:10px">
            ${MOCK.ideas.slice(0,3).map(idea => `
              <div style="background:var(--navy3);border-radius:8px;padding:12px;border-left:3px solid #FFB900">
                <div style="font-size:12px;font-weight:600;color:#fff;margin-bottom:4px">${idea.title}</div>
                <div style="display:flex;justify-content:space-between;align-items:center">
                  <div style="font-size:11px;color:#8496AB">${idea.date}</div>
                  <span class="idea-status status-${idea.status}">${idea.status === 'escalated' ? '↑ Escalated' : idea.status === 'stored' ? '📦 Stored' : '⏳ Pending'}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

      </div>

    </div>
  `;
}
