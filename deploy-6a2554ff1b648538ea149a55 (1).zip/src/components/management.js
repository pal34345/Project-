// ═══════════════════════════════════════════════
// MANAGEMENT DASHBOARD VIEW
// ═══════════════════════════════════════════════

function renderManagement() {
  const m = MOCK.management;
  const metrics = [
    { label:"Productivity Score",     val:m.productivity.score,      trend:m.productivity.trend,      color:"#0078D4" },
    { label:"Audit Pass Rate",        val:m.auditPassRate.score,      trend:m.auditPassRate.trend,     color:"#00B294" },
    { label:"Task Completion",        val:m.taskCompletion.score,     trend:m.taskCompletion.trend,    color:"#00BCF2" },
    { label:"Project Autonomy Score", val:m.autonomyScore.score,      trend:m.autonomyScore.trend,     color:"#F7630C" },
    { label:"Meeting Efficiency",     val:m.meetingEfficiency.score,  trend:m.meetingEfficiency.trend, color:"#7B2FBE" },
  ];

  return `
    <div style="display:flex;flex-direction:column;gap:20px">

      <div class="section-header">
        <div>
          <div class="section-title">Management Dashboard</div>
          <div class="section-sub">Productivity analytics · Audit performance · Innovation pipeline · Workforce insights</div>
        </div>
        <button class="btn btn-ghost" onclick="App.showToast('📄 Report exported')">Export Report</button>
      </div>

      <!-- KPI Row -->
      <div class="grid-4">
        <div class="stat-tile">
          <div class="stat-label">Productivity</div>
          <div class="stat-value">${m.productivity.score}%</div>
          <div class="stat-sub">${m.productivity.trend}</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">Audit Pass Rate</div>
          <div class="stat-value">${m.auditPassRate.score}%</div>
          <div class="stat-sub">${m.auditPassRate.trend}</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">Idea Briefs Received</div>
          <div class="stat-value">${m.ideaBriefs.count}</div>
          <div class="stat-sub">Latest: ${m.ideaBriefs.latest}</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">Project Autonomy</div>
          <div class="stat-value">${m.autonomyScore.score}%</div>
          <div class="stat-sub">${m.autonomyScore.trend}</div>
        </div>
      </div>

      <div class="grid-2">

        <!-- Performance Metrics -->
        <div class="card">
          <div class="card-title">Performance Overview</div>
          ${metrics.map(met => `
            <div class="metric-row">
              <div class="metric-label">${met.label}</div>
              <div class="metric-bar">
                <div class="metric-bar-fill" style="width:${met.val}%;background:${met.color}"></div>
              </div>
              <div class="metric-val">${met.val}%</div>
            </div>
          `).join('')}
          <div style="margin-top:14px;display:flex;flex-direction:column;gap:6px">
            ${metrics.map(met => `
              <div style="font-size:11px;color:#8496AB">• <strong style="color:#E8EFF7">${met.label}:</strong> ${met.trend}</div>
            `).join('')}
          </div>
        </div>

        <!-- Innovation Briefs + AI Recommendations -->
        <div style="display:flex;flex-direction:column;gap:14px">

          <!-- Idea Briefs -->
          <div class="card">
            <div class="card-title">Idea Briefs Received</div>
            <div style="display:flex;flex-direction:column;gap:8px">
              ${MOCK.ideas.filter(i=>i.status==='escalated').map(idea => `
                <div style="background:var(--navy3);border-radius:8px;padding:12px;border-left:3px solid #FFB900">
                  <div style="font-size:12px;font-weight:600;color:#fff;margin-bottom:4px">${idea.title}</div>
                  <div style="font-size:11px;color:#E8EFF7;line-height:1.5;margin-bottom:6px">${idea.brief}</div>
                  <div style="display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:10px;color:#8496AB">From: ${idea.submittedBy} · ${idea.date}</span>
                    <span style="font-size:10px;color:#00B294;font-weight:600">✅ Reviewed</span>
                  </div>
                </div>
              `).join('')}
              ${MOCK.ideas.filter(i=>i.status==='escalated').length === 0 ?
                '<div style="font-size:12px;color:#8496AB;text-align:center;padding:20px">No escalated ideas yet</div>' : ''}
            </div>
          </div>

          <!-- AI Recommendations -->
          <div class="card" style="background:rgba(0,120,212,0.06);border-color:rgba(0,120,212,0.2)">
            <div class="card-title">AI Recommendations</div>
            <div style="display:flex;flex-direction:column;gap:10px">
              <div style="display:flex;gap:10px;font-size:12px;color:#E8EFF7;line-height:1.5">
                <span style="color:#00BCF2;flex-shrink:0">→</span>
                3 projects are eligible for full autonomous scheduling based on current feasibility scores.
              </div>
              <div style="display:flex;gap:10px;font-size:12px;color:#E8EFF7;line-height:1.5">
                <span style="color:#FFB900;flex-shrink:0">→</span>
                2 ideas in the repository have high strategic alignment — consider fast-tracking to Q3 planning.
              </div>
              <div style="display:flex;gap:10px;font-size:12px;color:#E8EFF7;line-height:1.5">
                <span style="color:#00B294;flex-shrink:0">→</span>
                Audit pass rate stable at 94% — anomaly detection requires one manual review session.
              </div>
            </div>
          </div>

        </div>
      </div>

      <!-- Workload Heatmap-style row -->
      <div class="card">
        <div class="card-title">Team Workload Distribution</div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          ${['Pallab','Ritu S.','Ankit M.','Deepa K.','Suresh P.','Priya T.'].map((name,i) => {
            const load = [82,68,91,45,73,55][i];
            const col  = load > 85 ? '#D13438' : load > 70 ? '#F7630C' : '#00B294';
            return `
              <div style="flex:1;min-width:120px;background:var(--navy3);border-radius:8px;padding:14px">
                <div style="font-size:12px;font-weight:600;color:#fff;margin-bottom:8px">${name}</div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px">
                  <span style="font-size:10px;color:#8496AB">Load</span>
                  <span style="font-size:12px;font-weight:700;color:${col}">${load}%</span>
                </div>
                <div class="progress-bar">
                  <div class="progress-fill" style="width:${load}%;background:${col}"></div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>

    </div>
  `;
}
