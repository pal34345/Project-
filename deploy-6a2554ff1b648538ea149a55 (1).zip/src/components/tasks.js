// ═══════════════════════════════════════════════
// TASK ENGINE VIEW
// ═══════════════════════════════════════════════

function renderTasks() {
  return `
    <div style="display:flex;flex-direction:column;gap:20px">

      <div class="section-header">
        <div>
          <div class="section-title">Task Engine</div>
          <div class="section-sub">Daily tasks auto-submitted · Projects run on employee feasibility score</div>
        </div>
        <button class="btn btn-primary" onclick="TaskEngine.runAutoSubmit()">⚡ Run Auto-Submit</button>
      </div>

      <!-- Summary Stats -->
      <div class="grid-4">
        <div class="stat-tile">
          <div class="stat-label">Total Tasks</div>
          <div class="stat-value">${MOCK.tasks.length}</div>
          <div class="stat-sub muted">Today's queue</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">Auto-Submit</div>
          <div class="stat-value">${MOCK.tasks.filter(t=>t.autoSubmit).length}</div>
          <div class="stat-sub">Zero competition mode</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">Completed</div>
          <div class="stat-value">${MOCK.tasks.filter(t=>t.done).length}</div>
          <div class="stat-sub">of ${MOCK.tasks.length} tasks</div>
        </div>
        <div class="stat-tile">
          <div class="stat-label">High Priority</div>
          <div class="stat-value" style="color:#D13438">${MOCK.tasks.filter(t=>t.priority==='high').length}</div>
          <div class="stat-sub warn">Need attention</div>
        </div>
      </div>

      <!-- Auto-Submit Explainer -->
      <div style="background:rgba(0,120,212,0.08);border:1px solid rgba(0,120,212,0.25);border-radius:10px;padding:16px 20px;display:flex;gap:14px;align-items:flex-start">
        <div style="font-size:22px;flex-shrink:0">⚡</div>
        <div>
          <div style="font-size:13px;font-weight:600;color:#00BCF2;margin-bottom:4px">Auto-Submit Mode Active</div>
          <div style="font-size:12px;color:#8496AB;line-height:1.6">Daily routine tasks are auto-submitted at their deadline — no manual action required, no task-level competition. Projects are scheduled autonomously based on your current feasibility score of <strong style="color:#fff">${MOCK.user.feasibility}%</strong>. You only intervene when feasibility drops below 60%.</div>
        </div>
      </div>

      <div class="grid-2">

        <!-- Daily Tasks -->
        <div class="card">
          <div class="card-title">Daily Tasks</div>
          <div class="task-list" id="taskList">
            ${MOCK.tasks.map((t,i) => `
              <div class="task-item ${t.done?'done':''}" id="task-${t.id}" onclick="TaskEngine.toggleTask(${t.id})">
                <div class="task-check ${t.done?'checked':''}" id="check-${t.id}">${t.done?'✓':''}</div>
                <div style="flex:1">
                  <div class="task-name">${t.name}</div>
                  <div style="font-size:11px;color:#8496AB;margin-top:2px">${t.deadline}</div>
                </div>
                <div class="task-meta">
                  <span class="tag tag-${t.priority==='high'?'high':t.priority==='mid'?'mid':'low'}">${t.priority}</span>
                  ${t.autoSubmit ? '<span class="tag tag-auto">Auto</span>' : '<span style="font-size:10px;color:#8496AB">Manual</span>'}
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Projects + Feasibility -->
        <div style="display:flex;flex-direction:column;gap:14px">
          <div class="card">
            <div class="card-title">Project Autonomous Scheduler</div>
            <div style="display:flex;flex-direction:column;gap:16px">
              ${MOCK.projects.map(p => `
                <div style="background:var(--navy3);border-radius:8px;padding:14px">
                  <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">
                    <div class="feasibility-ring" style="--pct:${p.feasibility * 3.6}deg;width:60px;height:60px">
                      <div class="feasibility-val" style="font-size:13px">${p.feasibility}%</div>
                    </div>
                    <div style="flex:1">
                      <div style="font-size:13px;font-weight:600;color:#fff;margin-bottom:3px">${p.name}</div>
                      <div style="font-size:11px;color:#8496AB">Deadline: ${p.deadline}</div>
                      <div style="font-size:11px;margin-top:3px;color:${p.autonomous?'#00B294':'#F7630C'}">
                        ${p.autonomous ? '⚡ Autonomous scheduling ON' : '⚠ Manual intervention needed'}
                      </div>
                    </div>
                  </div>
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px">
                    <span style="font-size:11px;color:#8496AB">Progress</span>
                    <span style="font-size:11px;color:#8496AB">${p.progress}%</span>
                  </div>
                  <div class="progress-bar">
                    <div class="progress-fill" style="width:${p.progress}%;background:${p.autonomous?'var(--cyan)':'var(--orange)'}"></div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

      </div>
    </div>
  `;
}

const TaskEngine = {
  toggleTask(id) {
    const task = MOCK.tasks.find(t => t.id === id);
    if (!task) return;
    task.done = !task.done;
    const item  = document.getElementById(`task-${id}`);
    const check = document.getElementById(`check-${id}`);
    if (!item || !check) return;
    item.classList.toggle('done', task.done);
    check.classList.toggle('checked', task.done);
    check.textContent = task.done ? '✓' : '';
    App.showToast(task.done ? `✅ "${task.name}" marked complete` : `↩ Task restored`);
  },
  runAutoSubmit() {
    const autoTasks = MOCK.tasks.filter(t => t.autoSubmit && !t.done);
    autoTasks.forEach(t => { t.done = true; });
    App.navigate('tasks');
    App.showToast(`⚡ ${autoTasks.length} tasks auto-submitted — no competition mode active`);
  }
};
