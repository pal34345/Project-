// ═══════════════════════════════════════════════
// AI ASSISTANT BOT
// ═══════════════════════════════════════════════

const Bot = {
  init() {
    const fab   = document.getElementById('botFab');
    const panel = document.getElementById('botPanel');
    const close = document.getElementById('botClose');
    const send  = document.getElementById('botSend');
    const input = document.getElementById('botInput');

    if (!fab || !panel) return;

    fab.addEventListener('click', () => panel.classList.toggle('open'));
    if (close) close.addEventListener('click', () => panel.classList.remove('open'));
    if (send)  send.addEventListener('click', () => Bot.send());
    if (input) input.addEventListener('keydown', e => { if (e.key === 'Enter') Bot.send(); });
  },

  send() {
    const input = document.getElementById('botInput');
    if (!input || !input.value.trim()) return;
    const text = input.value.trim();
    input.value = '';

    Bot.addMsg(text, 'user');
    Bot.showTyping();

    setTimeout(() => {
      Bot.removeTyping();
      Bot.addMsg(Bot.getResponse(text), 'ai');
    }, 900 + Math.random() * 600);
  },

  getResponse(text) {
    const t = text.toLowerCase();
    if (t.includes('summar') || t.includes('meeting')) return MOCK.botResponses.summarise;
    if (t.includes('audit') || t.includes('compliance')) return MOCK.botResponses.audit;
    if (t.includes('email') || t.includes('draft')) return MOCK.botResponses.email;
    if (t.includes('idea') || t.includes('log') || t.includes('innov')) return MOCK.botResponses.idea;
    if (t.includes('task') || t.includes('submit') || t.includes('autosubmit')) return MOCK.botResponses.tasks;
    return MOCK.botResponses.default;
  },

  addMsg(text, role) {
    const container = document.getElementById('botMessages');
    if (!container) return;
    const div = document.createElement('div');
    div.className = `bot-msg ${role}`;
    // Format markdown-ish bold
    const formatted = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
    div.innerHTML = `<div class="msg-bubble">${formatted}</div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  },

  showTyping() {
    const container = document.getElementById('botMessages');
    if (!container) return;
    const div = document.createElement('div');
    div.className = 'bot-msg ai';
    div.id = 'typingIndicator';
    div.innerHTML = `<div class="msg-bubble"><div class="loading-dots"><span></span><span></span><span></span></div></div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  },

  removeTyping() {
    const el = document.getElementById('typingIndicator');
    if (el) el.remove();
  }
};
